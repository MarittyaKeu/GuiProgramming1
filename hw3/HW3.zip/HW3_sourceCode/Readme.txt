/* 
Name: Marittya Keu
Class: GUI 1 Programming
Professor: Wenjin Zhou
Due Date: 9/29/18
Assignment 3: CSS
*/


The link to the website is http://weblab.cs.uml.edu/~mkeu/hw3/index.html

Description: For this assignment, we were tasked to style the provided index.html file to a specific style. This must be done without making any changes to the main html file. To do so, I targeted specific elements, classes, and ids. I also used a grid template for the layout. Also, I used margins and paddings to create spacing and alignments. Overall, the homework was fairly easy besides styling the layout of the file.  